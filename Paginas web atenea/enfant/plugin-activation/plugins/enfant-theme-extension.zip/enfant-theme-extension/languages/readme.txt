Please visit the following links to learn more about translating WordPress plugins:
https://codex.wordpress.org/Function_Reference/load_plugin_textdomain
